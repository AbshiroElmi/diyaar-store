import{aa as n}from"./index-2EszZDpc.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
